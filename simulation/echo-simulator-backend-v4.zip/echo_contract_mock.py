"""
ECHO Contract Mock - Python simulation of ECHO smart contract logic
Translates core logic from ECHO-Shi-Contracts.sol into Python
"""

import json
from datetime import datetime, timedelta
from typing import Dict, List, Tuple, Optional

# ========== 四权力档位语义 ==========
POWER_LEVELS = {
    0: "禁",  # 完全禁止
    1: "己",  # 自我边界
    2: "亲",  # 关系边界
    3: "约",  # 契约边界
    4: "法",  # 规则边界
    5: "公",  # 自然边界
}

# ========== 事件类型定义（v2.1 - 扩展权重新定义） ==========
# 扩 = 封装使用（原内容不变）
# 衍 = 生成新ECHO资产

EVENT_TYPES = {
    # 接触类 — 验证「用」权力
    "view": {"category": "access", "power": "yong", "weight": 1, "default_on_chain": False},
    "preview": {"category": "access", "power": "yong", "weight": 1, "default_on_chain": False},
    
    # 扩展类 — 验证「扩」权力（封装使用，原内容不变）
    "reference": {"category": "extension", "power": "kuo", "weight": 3, "default_on_chain": True},
    "embed": {"category": "extension", "power": "kuo", "weight": 3, "default_on_chain": True},
    
    # 衍生类 — 验证「衍」权力（生成新ECHO资产）
    "remix": {"category": "derivation", "power": "yan", "weight": 5, "default_on_chain": True},
    "integrate": {"category": "derivation", "power": "yan", "weight": 4, "default_on_chain": True},
    "fork": {"category": "derivation", "power": "yan", "weight": 4, "default_on_chain": True},
    
    # 经济类 — 验证「益」权力
    "pay": {"category": "economic", "power": "yi", "weight": 5, "default_on_chain": True},
    "derivative_fee": {"category": "economic", "power": "yi", "weight": 5, "default_on_chain": True},
    "revenue_share": {"category": "economic", "power": "yi", "weight": 5, "default_on_chain": True},
    
    # 治理类
    "config_change": {"category": "governance", "power": None, "weight": 5, "default_on_chain": True},
    "shigraph_takeover": {"category": "governance", "power": None, "weight": 5, "default_on_chain": True},
    "dispute_resolve": {"category": "governance", "power": None, "weight": 5, "default_on_chain": True},
    
    # 协商类
    "remix_request": {"category": "negotiation", "power": None, "weight": 3, "default_on_chain": True},
    "auth_grant": {"category": "negotiation", "power": None, "weight": 3, "default_on_chain": True},
}

# ========== 卦象辅助函数（必须在 HEXAGRAMS 生成之前定义） ==========

def _get_hexagram_name(t, s, r):
    """根据维度生成卦象名称"""
    stages = ["潜藏", "显现", "勤勉", "试探", "大成", "转化"]
    total = t + s + r
    idx = min(total, 5)
    return stages[idx]

def _get_stage(t, s, r):
    """计算生命阶段"""
    total = t + s + r
    if total <= 1:
        return "萌芽"
    elif total <= 3:
        return "成长"
    elif total <= 5:
        return "成熟"
    else:
        return "转化"

# ========== 势位卦象定义（简化版 - 4×4×4 张量） ==========
# 每个卦象对应生命状态和四权力约束
HEXAGRAMS = {}

# 生成64个卦象的约束规则
for t in range(4):
    for s in range(4):
        for r in range(4):
            key = f"T[{t}][{s}][{r}]"
            
            # 基于维度计算约束
            # 时间维度影响「用」的约束
            time_factor = t  # 0=沉寂, 1=稳定, 2=活跃, 3=爆发
            
            # 空间维度影响「扩」的约束
            space_factor = s  # 0=单平台, 1=少平台, 2=多平台, 3=跨域
            
            # 关系维度影响「衍」的约束
            relation_factor = r  # 0=孤立, 1=初连, 2=网络, 3=生态
            
            # 约束逻辑：维度越高，要求越开放
            HEXAGRAMS[key] = {
                "name": _get_hexagram_name(t, s, r),
                "constraints": {
                    "yong": {"min": max(1, time_factor), "max": 5},
                    "kuo": {"min": max(1, space_factor), "max": 5},
                    "yan": {"min": max(0, relation_factor - 1), "max": 5},
                    "yi": {"min": 1, "max": 5},
                },
                "stage": _get_stage(t, s, r),
            }


class ECHOContractMock:
    """ECHO 合约逻辑模拟器"""
    
    def __init__(self):
        self.assets = {}  # asset_id -> asset_state
        self.users = {}   # user_id -> user_state
        self.events = []  # 所有事件记录
        self.relation_graph = {}  # (from, to) -> {count, weight}
        self.disputes = []  # 争议记录
        
    def register_asset(self, asset_id: str, creator_id: str, config: Dict, 
                       asset_type: str, created_at: str) -> Dict:
        """铸造资产 - 对应合约的初始配置"""
        
        # 验证配置合法性
        validation = self._validate_config(config)
        
        asset_state = {
            "id": asset_id,
            "creator_id": creator_id,
            "type": asset_type,
            "created_at": created_at,
            "config": config,  # 当前配置
            "config_history": [{"config": config.copy(), "timestamp": created_at, "reason": "初始铸造"}],
            "current_hexagram": "T[0][0][0]",  # 初始在潜藏
            "hexagram_history": [{"hexagram": "T[0][0][0]", "timestamp": created_at}],
            "events_7d": [],  # 最近7天事件
            "all_events": [],
            "view_count": 0,
            "reference_count": 0,
            "remix_count": 0,
            "pay_count": 0,
            "earnings": 0,
            "status": "active",
        }
        
        self.assets[asset_id] = asset_state
        
        # 生成铸造事件
        mint_event = self._create_event(
            event_type="config_change",
            subject_asset=asset_id,
            object_asset=None,
            platform_id="ECHO",
            user_id=creator_id,
            timestamp=created_at,
            details={"action": "mint", "initial_config": config}
        )
        self.events.append(mint_event)
        asset_state["all_events"].append(mint_event)
        
        return {
            "success": True,
            "asset": asset_state,
            "event": mint_event,
            "validation": validation,
        }
    
    def check_access(self, asset_id: str, user_id: str, action: str) -> Dict:
        """检查用户是否有权限对资产执行某个动作"""
        
        asset = self.assets.get(asset_id)
        if not asset:
            return {"allowed": False, "reason": "资产不存在"}
        
        config = asset["config"]
        
        # 根据动作类型检查对应的权力
        # v2.1 扩展权重新定义：
        # 扩 = 封装使用（原内容不变）
        # 衍 = 生成新ECHO资产
        if action in ["view", "preview"]:
            power_key = "yong"  # 用：裸内容的直接使用
        elif action in ["reference", "embed", "share"]:
            power_key = "kuo"   # 扩：封装使用，原内容不变
        elif action in ["remix", "integrate", "fork"]:
            power_key = "yan"   # 衍：生成新ECHO资产
        elif action in ["pay", "purchase"]:
            power_key = "yi"    # 益：收益分配
        else:
            return {"allowed": False, "reason": f"未知动作类型: {action}"}
        
        power_level = config.get(power_key, 0)
        
        # 检查权限
        if power_level == 0:
            return {
                "allowed": False,
                "reason": f"{power_key}=0（禁），此动作被禁止",
                "power": power_key,
                "level": power_level,
            }
        
        if power_level == 1 and action != "view":
            # 己档位：仅允许自我使用
            if user_id != asset["creator_id"]:
                return {
                    "allowed": False,
                    "reason": f"{power_key}=1（己），仅创作者可使用",
                    "power": power_key,
                    "level": power_level,
                }
        
        if power_level == 2 and action in ["remix", "integrate"]:
            # 亲档位：需要关系链证明（简化：检查是否有引用历史）
            has_relation = self._check_user_asset_relation(user_id, asset_id)
            if not has_relation:
                return {
                    "allowed": False,
                    "reason": f"{power_key}=2（亲），需要先有引用关系",
                    "power": power_key,
                    "level": power_level,
                    "suggestion": "先引用此资产，建立关系后可申请改编",
                }
        
        # 检查卦象约束
        hexagram = HEXAGRAMS.get(asset["current_hexagram"])
        if hexagram:
            constraints = hexagram["constraints"][power_key]
            if power_level < constraints["min"]:
                return {
                    "allowed": False,
                    "reason": f"当前势位 {asset['current_hexagram']} 要求 {power_key}≥{constraints['min']}",
                    "power": power_key,
                    "level": power_level,
                    "constraint": constraints,
                    "suggestion": "势位提升后自动解锁，或申请配置变更",
                }
        
        return {
            "allowed": True,
            "power": power_key,
            "level": power_level,
        }
    
    def process_event(self, asset_id: str, user_id: str, event_type: str,
                      platform_id: str, timestamp: str, details: Dict = None) -> Dict:
        """处理一个事件"""
        
        asset = self.assets.get(asset_id)
        if not asset:
            return {"success": False, "reason": "资产不存在"}
        
        # 检查权限
        access_check = self.check_access(asset_id, user_id, event_type)
        
        if not access_check["allowed"]:
            # 记录拒绝事件（用于统计和争议）
            reject_event = self._create_event(
                event_type=f"{event_type}_rejected",
                subject_asset=asset_id,
                object_asset=None,
                platform_id=platform_id,
                user_id=user_id,
                timestamp=timestamp,
                details={"reason": access_check["reason"], "attempted_action": event_type},
                on_chain=True,  # 拒绝事件也上链，用于争议追溯
            )
            self.events.append(reject_event)
            asset["all_events"].append(reject_event)
            
            return {
                "success": False,
                "reason": access_check["reason"],
                "event": reject_event,
                "suggestion": access_check.get("suggestion"),
            }
        
        # 决定事件是否上链
        event_info = EVENT_TYPES.get(event_type, {})
        
        # view 类事件：批量聚合上链
        on_chain = event_info.get("default_on_chain", False)
        if event_type in ["view", "preview"]:
            # 每 10 次浏览聚合上链一次（第10, 20, 30...次）
            on_chain = (asset["view_count"] + 1) % 10 == 0
        
        # 创建事件
        event = self._create_event(
            event_type=event_type,
            subject_asset=asset_id,
            object_asset=details.get("object_asset") if details else None,
            platform_id=platform_id,
            user_id=user_id,
            timestamp=timestamp,
            details=details,
            on_chain=on_chain,
        )
        
        self.events.append(event)
        asset["all_events"].append(event)
        asset["events_7d"].append(event)
        
        # 更新统计
        if event_type == "view":
            asset["view_count"] += 1
        elif event_type == "reference":
            asset["reference_count"] += 1
            self._add_relation_edge(asset_id, user_id, "reference")
        elif event_type == "remix":
            asset["remix_count"] += 1
            self._add_relation_edge(asset_id, user_id, "remix")
        elif event_type == "pay":
            asset["pay_count"] += 1
            amount = details.get("amount", 0) if details else 0
            asset["earnings"] += amount
        
        return {
            "success": True,
            "event": event,
            "on_chain": on_chain,
        }
    
    def request_config_change(self, asset_id: str, creator_id: str, 
                            new_config: Dict, timestamp: str, reason: str = "") -> Dict:
        """创作者申请修改配置"""
        
        asset = self.assets.get(asset_id)
        if not asset:
            return {"success": False, "reason": "资产不存在"}
        
        if asset["creator_id"] != creator_id:
            return {"success": False, "reason": "只有创作者可修改配置"}
        
        # 检查新配置是否合法
        validation = self._validate_config(new_config)
        if not validation["valid"]:
            return {"success": False, "reason": f"配置不合法: {validation['errors']}"}
        
        # 检查卦象约束
        hexagram = HEXAGRAMS.get(asset["current_hexagram"])
        if hexagram:
            for power_key, constraints in hexagram["constraints"].items():
                new_level = new_config.get(power_key, 0)
                if new_level < constraints["min"] or new_level > constraints["max"]:
                    return {
                        "success": False,
                        "reason": f"当前势位 {asset['current_hexagram']} 要求 {power_key} 在 [{constraints['min']}, {constraints['max']}] 之间",
                        "constraint": constraints,
                        "suggestion": "等待势位变化，或申请休眠后重新配置",
                    }
        
        # 记录历史
        old_config = asset["config"].copy()
        asset["config_history"].append({
            "config": new_config.copy(),
            "timestamp": timestamp,
            "reason": reason,
            "previous_config": old_config,
        })
        asset["config"] = new_config
        
        # 生成事件
        event = self._create_event(
            event_type="config_change",
            subject_asset=asset_id,
            object_asset=None,
            platform_id="ECHO",
            user_id=creator_id,
            timestamp=timestamp,
            details={
                "action": "config_update",
                "old_config": old_config,
                "new_config": new_config,
                "reason": reason,
            },
        )
        self.events.append(event)
        asset["all_events"].append(event)
        
        return {
            "success": True,
            "event": event,
            "old_config": old_config,
            "new_config": new_config,
        }
    
    def calculate_shi_position(self, asset_id: str, timestamp: str) -> Dict:
        """计算资产的势位（7天事件聚合）"""
        
        asset = self.assets.get(asset_id)
        if not asset:
            return {"success": False, "reason": "资产不存在"}
        
        # 清理超过7天的事件
        cutoff = datetime.fromisoformat(timestamp.replace("Z", "+00:00")) - timedelta(days=7)
        asset["events_7d"] = [
            e for e in asset["events_7d"]
            if datetime.fromisoformat(e["timestamp"].replace("Z", "+00:00")) > cutoff
        ]
        
        events = asset["events_7d"]
        
        # 计算三个维度
        # 时间维度：使用频率（需要更多事件才能升级）
        total_interactions = len([e for e in events if e["type"] != "config_change"])
        if total_interactions <= 10:
            time_level = 0  # 沉寂
        elif total_interactions <= 30:
            time_level = 1  # 稳定
        elif total_interactions <= 80:
            time_level = 2  # 活跃
        else:
            time_level = 3  # 爆发
        
        # 空间维度：扩展行为强度（封装使用次数）
        # v2.1 修改：从"平台分布"改为"扩展行为次数"
        # 扩 = 封装使用，原内容不变
        extension_events = [e for e in events if e["type"] in ["reference", "embed"]]
        extension_count = len(extension_events)
        if extension_count == 0:
            space_level = 0  # 无扩展
        elif extension_count <= 3:
            space_level = 1  # 少量扩展
        elif extension_count <= 8:
            space_level = 2  # 活跃扩展
        else:
            space_level = 3  # 广泛扩展
        
        # 关系维度：连接强度（需要更多关系事件）
        relation_events = [e for e in events if e["type"] in ["reference", "remix", "integrate"]]
        relation_count = len(relation_events)
        if relation_count == 0:
            relation_level = 0  # 孤立
        elif relation_count <= 3:
            relation_level = 1  # 初连
        elif relation_count <= 10:
            relation_level = 2  # 网络
        else:
            relation_level = 3  # 生态
        
        # 组合卦象
        new_hexagram = f"T[{time_level}][{space_level}][{relation_level}]"
        old_hexagram = asset["current_hexagram"]
        
        asset["current_hexagram"] = new_hexagram
        asset["hexagram_history"].append({
            "hexagram": new_hexagram,
            "timestamp": timestamp,
            "time_level": time_level,
            "space_level": space_level,
            "relation_level": relation_level,
        })
        
        # 检查配置是否仍然合规
        hexagram_info = HEXAGRAMS.get(new_hexagram, {})
        violations = []
        for power_key, constraints in hexagram_info.get("constraints", {}).items():
            current_level = asset["config"].get(power_key, 0)
            if current_level < constraints["min"]:
                violations.append({
                    "power": power_key,
                    "current": current_level,
                    "required_min": constraints["min"],
                    "message": f"{power_key}={current_level}，但势位要求 ≥{constraints['min']}",
                })
        
        return {
            "success": True,
            "asset_id": asset_id,
            "old_hexagram": old_hexagram,
            "new_hexagram": new_hexagram,
            "hexagram_info": hexagram_info,
            "dimensions": {
                "time": {"level": time_level, "count": total_interactions, "desc": "使用频率（沉寂→爆发）"},
                "space": {"level": space_level, "count": extension_count, "desc": "扩展强度（封装使用次数）"},
                "relation": {"level": relation_level, "count": relation_count, "desc": "衍生生态（新资产关联数）"},
            },
            "violations": violations,
            "needs_attention": len(violations) > 0,
        }
    
    def _validate_config(self, config: Dict) -> Dict:
        """验证四权力配置是否合法"""
        errors = []
        
        for key in ["yong", "kuo", "yan", "yi"]:
            if key not in config:
                errors.append(f"缺少 {key}")
            elif not isinstance(config[key], int):
                errors.append(f"{key} 必须是整数")
            elif config[key] < 0 or config[key] > 5:
                errors.append(f"{key}={config[key]} 超出范围 [0,5]")
        
        return {
            "valid": len(errors) == 0,
            "errors": errors,
        }
    
    def _check_user_asset_relation(self, user_id: str, asset_id: str) -> bool:
        """检查用户与资产是否已有关系"""
        edge_key = (asset_id, user_id)
        return edge_key in self.relation_graph
    
    def _add_relation_edge(self, asset_id: str, user_id: str, relation_type: str):
        """添加关系边"""
        edge_key = (asset_id, user_id)
        if edge_key not in self.relation_graph:
            self.relation_graph[edge_key] = {"count": 0, "types": set()}
        self.relation_graph[edge_key]["count"] += 1
        self.relation_graph[edge_key]["types"].add(relation_type)
    
    def _create_event(self, event_type: str, subject_asset: str, object_asset: Optional[str],
                      platform_id: str, user_id: str, timestamp: str,
                      details: Dict = None, on_chain: bool = True) -> Dict:
        """创建事件"""
        event = {
            "id": f"evt_{len(self.events):06d}",
            "type": event_type,
            "subject_asset": subject_asset,
            "object_asset": object_asset,
            "timestamp": timestamp,
            "platform_id": platform_id,
            "user_id": user_id,
            "on_chain": on_chain,
            "details": details or {},
        }
        return event
    
    def get_asset_state(self, asset_id: str) -> Optional[Dict]:
        """获取资产当前状态"""
        return self.assets.get(asset_id)
    
    def get_system_stats(self) -> Dict:
        """获取系统统计"""
        total_events = len(self.events)
        on_chain_events = len([e for e in self.events if e["on_chain"]])
        
        event_type_counts = {}
        for e in self.events:
            et = e["type"]
            event_type_counts[et] = event_type_counts.get(et, 0) + 1
        
        return {
            "total_events": total_events,
            "on_chain_events": on_chain_events,
            "on_chain_ratio": on_chain_events / total_events if total_events > 0 else 0,
            "asset_count": len(self.assets),
            "relation_edges": len(self.relation_graph),
            "event_type_counts": event_type_counts,
        }
